import React from 'react';
import axios from 'axios';
import logo from './logo.svg';
import './App.css';


class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {value: 'Hi, How are you?'};

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({value: event.target.value});
  }

  handleSubmit(event) {
    alert('You said: ' + this.state.value);
    axios.post('/user', {
      text: this.state.value
    })
    .then(function (response) {
      alert('Sahayk reponse: ' + response);
      console.log(response);
    })
    .catch(function (error) {
      alert('Sahayk said ' + error);
      console.log(error);
    });
    event.preventDefault();
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p>
            Hi, <code>I am sahayak</code>.
          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Feed Me
          </a>
          <form onSubmit={this.handleSubmit}>
            <label>
              Enter Text:
              <textarea value={this.state.value} onChange={this.handleChange}>
                
              </textarea>
            </label>
            <input type="submit" value="Submit" />
          </form>
        </header>
      </div>
    );
  }
}

export default App;
